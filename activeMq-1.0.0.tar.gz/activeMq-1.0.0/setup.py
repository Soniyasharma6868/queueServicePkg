from setuptools import setup, find_packages

setup(
    name='activeMq',
    version='1.0.0',
    packages=find_packages(),
    install_requires=['stomp.py'],
    description='A free queue service using ActiveMQ',
    author='Soniya Sharma',
    author_email='sharmasoniya6868@email.com',
    url='https://github.com/Soniyasharma6868/activeMqServices',
)
