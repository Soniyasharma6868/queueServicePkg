# activeMqServices
To build a free queue service in Python using ActiveMQ and package it as a reusable package, you can follow these steps:

Install the required dependencies:

Install ActiveMQ: Download and install ActiveMQ from the official website (http://activemq.apache.org/).
Install the stomp package: Use pip to install the stomp package, which provides STOMP protocol support for ActiveMQ. Run the following command:
                        pip install stomp
